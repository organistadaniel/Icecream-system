<!DOCTYPE html>
<html>
<head>
    <title>icecream</title>
</head>
<body>
<p>dandan lang mahina</p>

</body>
</html><?php /**PATH C:\Users\Heidi Lyn M. Ymson\Desktop\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>