<!DOCTYPE html>
<html>
	<head>
		<title>
		Ice
		</title>
		<link rel="icon" href="img/pic1.jpg" type="image">
		<link rel="stylesheet" href="css/style.css" type="text/css">
	</head>
	<style type="text/css">
		*{
padding:0;
margin:0;
}

body
{
background: url(../img/bg.jpg) center fixed; 
font-family:  Arial;
margin-bottom: 80px;
}

.about{
background: url(../img/transparent.png) repeat;
color:#ffffff;
height:50px;
text-align:center;
font-size:40px;
font-weight:bold;
}

.info {
float:left;
width:348px;
padding:15px;
margin:20px 10px;
background:#FFFF66;
border:1px solid #aaaaaa;
}

.box p {
	padding:20px 0;
}

span
{ color: #484848;
  text-shadow: 2px 2px #ffffff;}

.body
{
width: 80%;
height: auto;
float: left;
margin: auto;
margin-left:100px;
font-size: 20px;
}

input[type=text], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 20px;
}

input[type=password], select {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 20px;
}

button[type=submit] {
  width: 50%;
  background-color: #996515;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 20px;
}

.clr
{
clear: both;
}

#container
{
width: 85%;
height: auto;
margin: auto;
}

.header
{
  padding:10px;
  color:#484848;
  font-size:50px;
  height:150px;
  margin-top: 10px;
  margin-bottom:0px;
}

.header a{
font-size:20px;
}

.header p{
font-size:20px;
}

.hero{
  margin-top: 37px;
  margin-bottom: 10px;
  border: 1px solid #888888;
  border-radius: 3px;
}

#content{
 background: url(../img/transparent.png) repeat;
 color:white;
 width:72%;
 height:auto;
 border:1px solid #888888;
 overflow:auto;
 border-radius:5px;
}

.left
{
 float: left;
}

.right{
 float:right; 
 margin-top:-137px;
}

.logo
{
   margin-top:20px;
}
*{

  margin: 0;
  padding: 0;
  list-style: none;
  box-sizing: border-box;
  font-family: 'ubuntu', sans-serif
}
body{
background: #e7e7e9;
}
.wrapper{
  width: 100%;
}
.mega_menu{
  width: 100%
  height: 60px%
}
.mega_menu ul{
  width: 100%
  height: 100%
  background: #000000;
  text-align: center;
  line-height: 60px;
  position: relative;
}
.mega_menu ul li{
  display: inline-block;
  margin: 0 15px;
  padding: 0 15px;
}
.mega_menu ul li a{
  text-decoration: none;
  color: #fff;
  text-transform: uppercase;
  font-weight:  bold;
  letter-spacing: 5px;
  font-size: 12px;
}
.title{
   font-size: 40px;
}

.bg
{
  color:#000000;
  margin-bottom: 20px;
  background-color: #fdd835;
  border-top: 1px solid #aaaaaa;
  width: 100%;
  overflow: hidden;
}

footer {
  color:#ffffff;
  position: absolute;
  background-color: #fdd835;
  width: 84%;
  height: 10%;
  border: 1px solid #888888;
  border-radius: 5px;
  font-size: 20px;
}


	</style>
	<body>
	<div id="container">
		<div class="header">

			<div class="logo"><img src="img/logo.png" width="130" class="left"> &nbsp;
			<div>
			<div class="title"> 
			<span>Aice Ice Cream</span><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></div>
			<div class="right">
			</div>
		</div>
	
		<div class="hero"><img src="img/img.png" width="100%" height="280">
		</div>	
		<div class="bg">
		<div class="body">
			<br>
			<br>
			<center>
				<input type="text" placeholder="First Name" name="fname" id="firstname" required><br><br>
                <input type="text" placeholder="Last Name" name="lname" id="lastname" required><br><br>
                <input type="text" placeholder="Email" name="email" required><br><br>
                <input type="password" placeholder="password" name="password" required><br><br>
                <input type="password" placeholder="Confirm password" name="password" required><br><br>
               <br>
            <h5>Already signed up? Click here to login.</h5>
               <br>
               <button type="submit" name="SignUp">Sign Up</button> 
               <br>
               <br>
            </center>
            </div>  
    <div class="bg">
    <div class="body">
      <br>
      <br>
<br> </br>
 <center> 
                <input type="text" placeholder="Email" name="email" required><br><br>
                <input type="password" placeholder="password" name="password" required><br><br>
               <br>
            <h5>Already signed up? Click here to login.</h5>
               <br>
               <button type="submit" name="SignUp">log in</button> 
               <br>
               <br>
        </div>
    </div>
		<div class="clr"></div>
	<footer>
		<br>
 <div class="wrapper">
   <div class="mega_menu">
           <ul>
             <li><a href="#">product</a></li>
             <li><a href="#">price</a></li>
             <li><a href="#">flavor</a></li>
           </ul>
         </div>
		<center><span>MADALE 2018</span></center>
		</footer>
	</body>


</html>